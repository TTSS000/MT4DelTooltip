﻿// dllmain.cpp : DLL アプリケーションのエントリ ポイントを定義します。
#include "pch.h"
#include <commctrl.h>
#include <stdio.h>
//#include <regex>

//using namespace std;

#define MT4_EXPFUNC __declspec(dllexport)
HWND g_hWndToolTip = 0;

void CreateConsole(void) {
  FILE* fp;
  AllocConsole();
  freopen_s(&fp, "CONOUT$", "w", stdout); /* 標準出力(stdout)を新しいコンソールに向ける */
  freopen_s(&fp, "CONOUT$", "w", stderr); /* 標準エラー出力(stderr)を新しいコンソールに向ける */
}

BOOL APIENTRY DllMain( HMODULE hModule,
                       DWORD  ul_reason_for_call,
                       LPVOID lpReserved
                     )
{
    switch (ul_reason_for_call)
    {
    case DLL_PROCESS_ATTACH:
      //CreateConsole();  // for debug console
    case DLL_THREAD_ATTACH:
    case DLL_THREAD_DETACH:
    case DLL_PROCESS_DETACH:
        break;
    }
    return TRUE;
}

BOOL CALLBACK EnumWindowsProc(HWND hwnd, LPARAM lParam)
{
  char classname[256];
  BOOL bRet = TRUE;
  HWND hWndParent = (HWND)lParam;

  GetClassNameA(hwnd, classname, 256);
  if (0 <= strcmp(classname, "tooltips_class32")) {
    if (hWndParent == GetWindow(hwnd, GW_OWNER)) {
      g_hWndToolTip = hwnd;
      bRet = FALSE;
    }
  }
  return bRet;
}

MT4_EXPFUNC HWND __stdcall DisableTooltip(HWND hWndParent, wchar_t* lpt_w_string1, wchar_t* lpt_w_string2)
{
  //TOOLINFO ti = { 0 };

  wchar_t w_tmpchar[256];
  //char tmpchar[256];

  g_hWndToolTip = 0;
  EnumWindows(EnumWindowsProc, (LPARAM) hWndParent);
  if (0 != g_hWndToolTip) {
    //ti.cbSize = sizeof(TOOLINFO);
    //ti.hwnd = hWndParent;
    //ti.lpszText = w_tmpchar;
    //const wchar_t* pattern = L"vs.+最終";
    //const wchar_t* pattern = L"vs";

    //SendMessage(g_hWndToolTip, TTM_GETCURRENTTOOL, 0, (LPARAM)&ti);
    //SendMessage(g_hWndToolTip, TTM_GETTOOLINFO, 0, (LPARAM)&ti);
    //if(0 != ti.uId){
      //fprintf_s(stderr, "ti.uId=%u\n", ti.uId); /* 標準エラー出力 */
    //}
    //fprintf_s(stderr, "ti.uId=%u\n", ti.uId); /* 標準エラー出力 */
    //SendMessage(g_hWndToolTip, TTM_GETTEXT, 256, (LPARAM)&ti);
    //fprintf_s(stderr, "ti.lpszText=%s\n", ti.lpszText); /* 標準エラー出力 */
    SendMessage(g_hWndToolTip, WM_GETTEXT, 256, (LPARAM)w_tmpchar);
    if (0 < wcslen(w_tmpchar)) {
      //fwprintf_s(stderr, L"w text=%ws\n", w_tmpchar); /* 標準エラー出力 */
      //wregex re(pattern);
      //if (regex_match(w_tmpchar, re)) {
      //  fwprintf_s(stderr, L"matched\n"); /* 標準エラー出力 */
      //}
      //if (0<=wcscmp(w_tmpchar, "vs")) {
      //  fwprintf_s(stderr, L"matched2\n"); /* 標準エラー出力 */
      //}
      if (0 < wcsstr(w_tmpchar, lpt_w_string1) && 0 < wcsstr(w_tmpchar, lpt_w_string2)) {
        PostMessage(g_hWndToolTip, TTM_ACTIVATE, FALSE, 0);
            //fwprintf_s(stderr, L"matched3\n"); /* 標準エラー出力 */
      }
      //if (0 < wcsstr(w_tmpchar, L"最終")) {
      //  fwprintf_s(stderr, L"matched4\n"); /* 標準エラー出力 */
      //}
    }

    //SendMessage(g_hWndToolTip, WM_GETTEXT, 256, (LPARAM)tmpchar);
    //if(0<strlen(tmpchar))     fprintf_s(stderr, "a text=%s\n", tmpchar); /* 標準エラー出力 */



  }
  return g_hWndToolTip;
}
