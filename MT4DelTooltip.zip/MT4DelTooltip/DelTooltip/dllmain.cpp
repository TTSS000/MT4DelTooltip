﻿// dllmain.cpp : DLL アプリケーションのエントリ ポイントを定義します。
#include "pch.h"
#include <commctrl.h>

#define MT4_EXPFUNC __declspec(dllexport)
HWND g_hWndToolTip = 0;

BOOL APIENTRY DllMain( HMODULE hModule,
                       DWORD  ul_reason_for_call,
                       LPVOID lpReserved
                     )
{
    switch (ul_reason_for_call)
    {
    case DLL_PROCESS_ATTACH:
    case DLL_THREAD_ATTACH:
    case DLL_THREAD_DETACH:
    case DLL_PROCESS_DETACH:
        break;
    }
    return TRUE;
}

BOOL CALLBACK EnumWindowsProc(HWND hwnd, LPARAM lParam)
{
  char classname[256];
  BOOL bRet = TRUE;
  HWND hWndParent = (HWND)lParam;

  GetClassNameA(hwnd, classname, 256);
  if (0 <= strcmp(classname, "tooltips_class32")) {
    if (hWndParent == GetWindow(hwnd, GW_OWNER)) {
      g_hWndToolTip = hwnd;
      bRet = FALSE;
    }
  }
  return bRet;
}

MT4_EXPFUNC void __stdcall DisableTooltip(HWND hWndParent)
{
  g_hWndToolTip = 0;
  EnumWindows(EnumWindowsProc, (LPARAM) hWndParent);
  if (0 != g_hWndToolTip) {
    PostMessage(g_hWndToolTip, TTM_ACTIVATE, FALSE, 0);
  }
  return;
}
